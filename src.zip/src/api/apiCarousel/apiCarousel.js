// USER DATA
const apiCarousel = [
    {
        id: 1,
        image: require('../../../public/banner/banner-02.jpg'),
    },
    {
        id: 2,
        image: require('../../../public/banner/banner-03.jpg'),
    },
    {
        id: 3,
        image: require('../../../public/banner/banner-04.jpg'),
    },
    {
        id: 3,
        image: require('../../../public/banner/banner-05.jpg'),
    },
]

export default apiCarousel;