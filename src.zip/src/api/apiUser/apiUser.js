// USER DATA
const apiUser = [
    {
        id: 1,
        avatar: require('../../../public/user/avatar-user-03.jpg'),
        userName: 'Nuraliyah',
        email: 'nuraliyah@gmail.com',
        phone: '08123456789',
        wallet: '1.000.000',
        poin: '10.000',
        voucher: '4'
    }
]

export default apiUser;