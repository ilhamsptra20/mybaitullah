import IlustrationPattern1 from './ilustration-pattern-01.png';
import IlustrationPattern2 from './ilustration-pattern-02.jpeg';
import IlustrationPattern3 from './ilustration-pattern-03.jpg';
import IlustrationPattern4 from './ilustration-pattern-04.jpg';
import IlustrationPattern5 from './ilustration-pattern-05.png';
import IlustrationEmptyContent from './ilustration-empty-content.svg';
import IlustrationSuccess from './ilustration-success.svg';
import IlustrationPending from './ilustration-pending.svg';
import IlustrationContainerTicket from './ilustration-container-ticket.png';
import IlustrationContainerTicketActive from './ilustration-container-ticket-active.png';
import IlustrationContainerTicketNonactive from './ilustration-container-ticket-nonactive.png';
import IlustrationContainerQrCode from './ilustration-container-qrcode.png';
import maghrib from './maghrib-01.png';

export {
    IlustrationPattern1,
    IlustrationPattern2,
    IlustrationPattern3,
    IlustrationPattern4,
    IlustrationPattern5,
    IlustrationEmptyContent,
    IlustrationSuccess,
    IlustrationPending,
    IlustrationContainerTicket,
    IlustrationContainerTicketActive,
    IlustrationContainerTicketNonactive,
    IlustrationContainerQrCode,
    maghrib,
}