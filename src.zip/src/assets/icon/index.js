import IconHomeActive from './icon-home-active.svg';
import IconHomeNonActive from './icon-home-nonactive.svg';
import IconTawafActive from './icon-tawaf-active.svg';
import IconTawafNonActive from './icon-tawaf-nonactive.svg';
import IconTicketActive from './icon-ticket-active.svg';
import IconTicketNonActive from './icon-ticket-nonactive.svg';
import IconTicket02 from './icon-tiket-02.png';
import IconCeritaBaitullahActive from './icon-cerita-baitullah-active.svg';
import IconCeritaBaitullahNonactive from './icon-cerita-baitullah-nonactive.svg';
import IconCeritaBaitullah02 from './icon-cerita-baitullah-02.png';
import IconProfileActive from './icon-profile-active.svg';
import IconProfileNonActive from './icon-profile-nonactive.svg';
import IconNotification from './icon-notification.svg';
import IconUserLine from './icon-user-line.svg'
import IconAlquran from './icon-alquran.svg'
import IconAlquran02 from './icon-alquran-02.png'
import IconDoa from './icon-doa.svg'
import IconDoa02 from './icon-doa-02.png'
import IconKiblat from './icon-kiblat.svg'
import IconKiblat02 from './icon-kiblat-02.png'
import IconTabungan1 from './icon-tabungan-01.png'
import IconTabungan2 from './icon-tabungan-02.png'
import IconTabungan3 from './icon-tabungan-03.png'
import IconCaretLeftWhite from './icon-caret-left-white.svg'
import IconCaretLeftBlack from './icon-caret-left-black.svg'
import IconCaretLeftGreen from './icon-caret-left-green.svg'
import IconCaretRightGreen from './icon-caret-right-green.svg'
import IconCaretUpGreen from './icon-caret-up-green.svg'
import IconCaretDownGreen from './icon-caret-down-green.svg'
import IconCalendarWhite from './icon-calendar-white.svg'
import IconCalendarGrey from './icon-calendar-grey.svg'
import IconCalendarGreen from './icon-calendar-green.svg'
import IconCalendarTag from './icon-calendar-tag.svg'
import IconLoginWhite from './icon-login-white.svg'
import IconNotificationWhite from './icon-notification-white.svg'
import IconNotificationWhite2 from './icon-notification-white-02.svg'
import IconMenuBlack from './icon-menu-black.svg'
import IconMenuWhite from './icon-menu-white.svg'
import IconMenuGreen from './icon-menu-green.svg'
import IconXMarkWhite from './icon-xmark-white.svg'
import IconCardTagDarkGreen from './icon-card-tag-darkgreen.png'
import IconSearchWhite from './icon-search-white.svg'
import IconSearcDarkgreen from './icon-search-darkgreen.png'
import IconFilterWhite from './icon-filter-white.svg'
import IconArrowLeftWhite from './icon-arrow-left-white.svg'
import IconArrowLeftGreen from './icon-arrow-left-green.svg'
import IconOne from './icon-one.svg'
import IconTwo from './icon-two.svg'
import IconThree from './icon-three.svg'
import IconDiscount1 from './icon-discount-01.png'
import IconDiscount2 from './icon-discount-02.png'
import IconClockGreen from './icon-clock-green.svg'
import IconLocationGreen from './icon-location-green.svg'
import IconCheckWhite from './icon-check-white.svg'
import IconCheckGreen from './icon-check-green.svg'
import IconMinusWhite from './icon-minus-white.svg'
import IconPlusWhite from './icon-plus-white.svg'
import IconBiodataActive from './icon-biodata-active.svg'
import IconBiodataNonactive from './icon-biodata-nonactive.svg'
import IconBayarActive from './icon-bayar-active.svg'
import IconBayarNonactive from './icon-bayar-nonactive.svg'
import IconQrcodeActive from './icon-qrcode-active.svg'
import IconQrcodeNonactive from './icon-qrcode-nonactive.svg'
import IconDownloadWhite from './icon-download-white.svg'
import IconDownloadGreen from './icon-download-green.svg'
import IconCopyGreen from './icon-copy-green.svg'
import IconAddUserWhite from './icon-user-add-white.svg'
import IconAddUserBlack from './icon-user-add-black.svg'
import IconWarningGreen from './icon-warning-green.svg'
import IconUserGrey from './icon-user-grey.svg'
import IconShareGrey from './icon-share-grey.svg'

export {
    IconHomeActive,
    IconHomeNonActive,
    IconTawafActive,
    IconTawafNonActive,
    IconTicketActive,
    IconTicketNonActive,
    IconTicket02,
    IconCeritaBaitullahActive,
    IconCeritaBaitullahNonactive,
    IconCeritaBaitullah02,
    IconProfileActive,
    IconProfileNonActive,
    IconNotification,
    IconUserLine,
    IconAlquran,
    IconAlquran02,
    IconDoa,
    IconDoa02,
    IconKiblat,
    IconKiblat02,
    IconTabungan1,
    IconTabungan2,
    IconTabungan3,
    IconCaretLeftWhite,
    IconCaretLeftBlack,
    IconCaretLeftGreen,
    IconCaretRightGreen,
    IconCaretUpGreen,
    IconCaretDownGreen,
    IconCalendarWhite,
    IconCalendarGrey,
    IconCalendarGreen,
    IconCalendarTag,
    IconLoginWhite,
    IconNotificationWhite,
    IconNotificationWhite2,
    IconMenuBlack,
    IconMenuWhite,
    IconMenuGreen,
    IconXMarkWhite,
    IconCardTagDarkGreen,
    IconSearchWhite,
    IconSearcDarkgreen,
    IconFilterWhite,
    IconArrowLeftWhite,
    IconArrowLeftGreen,
    IconOne,
    IconTwo,
    IconThree,
    IconDiscount1,
    IconDiscount2,
    IconClockGreen,
    IconLocationGreen,
    IconCheckWhite,
    IconCheckGreen,
    IconMinusWhite,
    IconPlusWhite,
    IconBiodataActive,
    IconBiodataNonactive,
    IconBayarActive,
    IconBayarNonactive,
    IconQrcodeActive,
    IconQrcodeNonactive,
    IconDownloadWhite,
    IconDownloadGreen,
    IconCopyGreen,
    IconAddUserWhite,
    IconAddUserBlack,
    IconWarningGreen,
    IconUserGrey,
    IconShareGrey,
}