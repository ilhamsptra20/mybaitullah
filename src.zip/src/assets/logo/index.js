import LogoBaitullah from './logo-baitullah-01.png'
import LogoAgentAlfamart from './logo-agent-alfamart.png'
import LogoAgentIndomaret from './logo-agent-indomaret.png'
import LogoBankBCA from './logo-bank-bca.png'
import LogoBankBNI from './logo-bank-bni.png'
import LogoBankBRI from './logo-bank-bri.png'
import LogoBankBSI from './logo-bank-bsi.png'
import LogoBankMandiri from './logo-bank-mandiri.png'
import LogoBankPermata from './logo-bank-permata.png'

export {
    LogoBaitullah,
    LogoAgentAlfamart,
    LogoAgentIndomaret,
    LogoBankBCA,
    LogoBankBNI,
    LogoBankBRI,
    LogoBankBSI,
    LogoBankMandiri,
    LogoBankPermata,
}