import { StyleSheet, Text, View, ImageBackground } from 'react-native';
import React, { useState, useEffect } from 'react';
import BaseStyle from '../../../assets/style/AppStyle.js';
import { maghrib } from '../../../assets';

const JadwalShalat = ({ jadwalShalat, loadingJadwalShalat }) => {
  const [filteredPrayerTimes, setFilteredPrayerTimes] = useState([]);
  const [nextPrayer, setNextPrayer] = useState(null);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!loadingJadwalShalat && jadwalShalat?.data) {
      const prayerTimes = jadwalShalat.data;

      // Daftar waktu salat yang ingin diambil
      const selectedTimes = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

      // Menyaring waktu salat berdasarkan waktu yang diinginkan
      const prayerValue = selectedTimes.map((time) => ({
        name: time,
        time: prayerTimes[time],
      }));

      setFilteredPrayerTimes(prayerValue);

      // Hitung waktu sholat terdekat
      calculateNextPrayer(prayerValue);
    }
  }, [loadingJadwalShalat, jadwalShalat]);

  const calculateNextPrayer = (prayers) => {
    const now = new Date();
    const upcoming = prayers
      .map((prayer) => {
        const [hours, minutes] = prayer.time.split(':');
        const prayerTime = new Date();
        prayerTime.setHours(hours, minutes, 0, 0);
        return { ...prayer, timeLeft: prayerTime - now };
      })
      .filter((prayer) => prayer.timeLeft > 0)
      .sort((a, b) => a.timeLeft - b.timeLeft);

    if (upcoming.length > 0) {
      setNextPrayer(upcoming[0]);
      setTimeLeft(upcoming[0].timeLeft);
    }
  };

  useEffect(() => {
    if (nextPrayer) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1000) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1000;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [nextPrayer]);

  const formatTimeLeft = (ms) => {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
    const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
    const seconds = String(totalSeconds % 60).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  };

  return (
    <ImageBackground
      source={maghrib}
      style={[
        BaseStyle.column,
        BaseStyle.justifyBetween,
        BaseStyle.BgWhite,
        BaseStyle.shadow,
        BaseStyle.p10,
        BaseStyle.radius20,
        { height: 240 },
      ]}
      imageStyle={{ borderRadius: 20 }}
    >
      <Text style={[BaseStyle.textSM, BaseStyle.MaisonDemi, BaseStyle.textBlack]}>Jakarta</Text>
      {nextPrayer && (
        <View>
          <Text
            style={[
              BaseStyle.textXS,
              BaseStyle.MaisonDemi,
              BaseStyle.textBlack,
              BaseStyle.textCenter,
            ]}
          >
            Waktu Tersisa Menuju Sholat {nextPrayer.name}
          </Text>
          <Text
            style={[
              BaseStyle.MaisonExtendExtra,
              BaseStyle.textBlack,
              BaseStyle.textCenter,
              { fontSize: 36 },
            ]}
          >
            {formatTimeLeft(timeLeft)}
          </Text>
        </View>
      )}
      <View
        style={[
          BaseStyle.row,
          BaseStyle.justifyBetween,
          BaseStyle.alignItemsCenter,
        ]}
      >
        {!loadingJadwalShalat && filteredPrayerTimes.length > 0 ? (
          filteredPrayerTimes.map((item) => (
            <View key={item.name} style={[BaseStyle.alignItemsCenter]}>
              <Text
                style={[
                  BaseStyle.textXS,
                  BaseStyle.MaisonBook,
                  BaseStyle.textBlack,
                ]}
              >
                {item.name}
              </Text>
              <Text
                style={[
                  BaseStyle.textXS,
                  BaseStyle.MaisonBook,
                  BaseStyle.textBlack,
                ]}
              >
                {item.time}
              </Text>
            </View>
          ))
        ) : (
          <></>
        )}
      </View>
    </ImageBackground>
  );
};

export default JadwalShalat;

const styles = StyleSheet.create({});
