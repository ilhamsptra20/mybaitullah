import { StyleSheet, Text, View, Image, Dimensions } from 'react-native'
import React from 'react'

// COMPONENT
import LinearGradient from 'react-native-linear-gradient';

// STYLE
import BaseStyle from '../../../assets/style/AppStyle.js'

const index = ({menu}) => {
  const limitedData = menu.slice(0, 3);
  return (
    <>
        {limitedData.map((item, y) => {
            return (
                <View key={y} style={[BaseStyle.w70, BaseStyle.alignItemsCenter]}>
                    <LinearGradient colors={item.color} style={[BaseStyle.justifyCenter, BaseStyle.alignItemsCenter, BaseStyle.w60, BaseStyle.h60, BaseStyle.radius60]}>
                        <Image source={item.icon} style={[BaseStyle.w40, BaseStyle.h40]} />
                    </LinearGradient>
                    <Text style={[BaseStyle.textXS2, BaseStyle.MaisonBook, BaseStyle.textBlack, BaseStyle.textCenter, BaseStyle.pt5]}>{item.title}</Text>
                </View>
            )
        })}
    </>
  )
}

export default index

const styles = StyleSheet.create({})