import React, { useRef } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, Animated, Dimensions } from 'react-native';
import { IlustrationPattern2 } from '../../../assets';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const HEADER_MAX_HEIGHT = 250;
const HEADER_MIN_HEIGHT = 80;
const HEADER_SCROLL_DISTANCE = HEADER_MAX_HEIGHT - HEADER_MIN_HEIGHT;

const HeaderImageScrollView = () => {
  const scrollY = useRef(new Animated.Value(0)).current;

  const headerHeight = scrollY.interpolate({
    inputRange: [0, HEADER_SCROLL_DISTANCE],
    outputRange: [HEADER_MAX_HEIGHT, HEADER_MIN_HEIGHT],
    extrapolate: 'clamp',
  });

  const imageTranslateY = scrollY.interpolate({
    inputRange: [0, HEADER_SCROLL_DISTANCE],
    outputRange: [0, -50],
    extrapolate: 'clamp',
  });

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.header, { height: headerHeight }]}> 
        <Animated.Image
          source={IlustrationPattern2}
          style={[styles.headerImage, { transform: [{ translateY: imageTranslateY }] }]}
        />
      </Animated.View>
      <Animated.ScrollView
        style={styles.scrollView}
        scrollEventThrottle={16}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        contentContainerStyle={styles.scrollViewContent} // Menambahkan contentContainerStyle
      >
        <View style={styles.content}>
          <Text style={styles.text}>Scroll down to see the effect!</Text>
          <Text style={styles.text}>Enjoy your coffee while reading more content below.</Text>
          <View style={styles.additionalContent}>
            <Text style={styles.contentText}>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam scelerisque ligula at turpis porta, id laoreet nunc tristique. Integer ac metus ac massa scelerisque convallis.</Text>
            <Text style={styles.contentText}>Duis at eros ut tortor venenatis tincidunt. Proin vulputate, odio non pharetra efficitur, felis augue vulputate arcu, id congue mauris metus et odio.</Text>
            <Text style={styles.contentText}>Suspendisse potenti. Aenean euismod, lectus at gravida sagittis, lorem ligula sagittis libero, ut dictum nulla neque eget neque.</Text>
            <Text style={styles.contentText}>Vestibulum vitae sapien et lacus cursus condimentum. Cras ut lacus id elit vehicula cursus ut eget odio.</Text>
          </View>
        </View>
      </Animated.ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'black',
    overflow: 'hidden',
  },
  headerImage: {
    width: '100%',
    height: HEADER_MAX_HEIGHT,
    resizeMode: 'cover',
  },
  scrollView: {
    flex: 1,
  },
  scrollViewContent: {
    paddingTop: HEADER_MAX_HEIGHT, // Menggunakan paddingTop untuk memberi ruang di bawah header
  },
  content: {
    padding: 20,
    minHeight: SCREEN_HEIGHT * 1.5, // Memastikan kontennya cukup panjang untuk scrolling
  },
  text: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
  },
  additionalContent: {
    marginTop: 20,
  },
  contentText: {
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 15,
  },
});

export default HeaderImageScrollView;
