import { StyleSheet, Text, TouchableOpacity } from 'react-native'
import React from 'react'

const Button = ({navigation, text, color, backgroundColor, borderRadius, borderColor=null, width='auto', paddingVertical=6, onPress}) => {
  return (
    <TouchableOpacity activeOpacity={0.7} navigation={navigation} onPress={onPress} style={styles.container(backgroundColor, borderRadius, borderColor, width)}>
      <Text style={styles.text(color, paddingVertical)}>{text}</Text>
    </TouchableOpacity>
  )
}

export default Button

const styles = StyleSheet.create({
    container: (backgroundColor, borderRadius, borderColor, width) => ({
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: backgroundColor,
      borderRadius: borderRadius,
      width: width,
      borderWidth: borderColor === null ? 0 : 1,
      borderColor: borderColor
    }),
    text: (color, paddingVertical) => ({
        fontFamily: 'MaisonNeue-Book',
        fontSize: 14,
        color: color,
        paddingVertical: paddingVertical,
        paddingHorizontal: 20,
    }),
})