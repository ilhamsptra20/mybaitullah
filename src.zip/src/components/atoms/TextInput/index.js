import React from 'react'
import { StyleSheet, Text, View, TextInput as TextInputRN, Image } from 'react-native'
import BaseStyle from '../../../assets/style/AppStyle.js'

const TextInput = ({lable, placeholder, placeholderColor='#696B6B', icon, width='100%', keyboardType, value, onChange, ...restProps}) => {
  return (
    <View style={[styles.container(width), BaseStyle.borderGray200, BaseStyle.radius10]}>
      <Text style={[BaseStyle.absolute, BaseStyle.MaisonBold, BaseStyle.textBlack, BaseStyle.textXS, BaseStyle.mb10, BaseStyle.index1, ({left: 10, top: 10})]}>{lable}</Text>
      {/* {icon !== null && <Image source={icon} style={[BaseStyle.absolute, BaseStyle.index1, ({width: 18, height: 18, top: 8, left: 8})]} />} */}
      <TextInputRN style={styles.text(placeholderColor)} placeholder={placeholder} keyboardType={keyboardType} {...restProps} placeholderTextColor={placeholderColor} value={value} onChange={onChange} />
    </View>
  )
}

export default TextInput

const styles = StyleSheet.create({
    container: (width) => ({
      position: 'relative',
      width: width,
      paddingHorizontal: 8,
      paddingTop: 24
    }),
    text: (placeholderColor) =>({
      alignItems: 'center',
      backgroundColor: 'white',
      color: placeholderColor,
      fontSize: 13,
      fontFamily: 'MaisonNeue-Book',
    })
})