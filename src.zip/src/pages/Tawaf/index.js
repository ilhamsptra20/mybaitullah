import React, { useState } from 'react';
import {View, Text, StyleSheet, ScrollView, ImageBackground, Animated, StatusBar, Dimensions} from 'react-native';

// COMPONENT
import { HeaderLogin, HeaderNotLogin } from '../../components/index.js'

// STYLE
import BaseStyle from '../../assets/style/AppStyle.js'

// API
import userData from '../../hook/user/userFetch.js'

// ASSETS
import { IlustrationPattern2 } from '../../assets';

const Tawaf = () => {
  const width = Dimensions.get('window').width;
  
  // status 0 belum login
  // status 1 sudah login
  let [status, setStatus] = useState(1);

  // NAVBACKGROUND
  const [nav, setNav] = useState(false)

  // USER DATA
  const {user, loadingUser, errorUser} = userData();

  const [scrollY] = useState(new Animated.Value(0));

  const HEADER_MAX_HEIGHT = 200; // Tinggi maksimum header
  const HEADER_MIN_HEIGHT = 60; // Tinggi minimum header
  const HEADER_SCROLL_DISTANCE = HEADER_MAX_HEIGHT - HEADER_MIN_HEIGHT;

  const headerHeight = scrollY.interpolate({
    inputRange: [0, HEADER_SCROLL_DISTANCE],
    outputRange: [HEADER_MAX_HEIGHT, HEADER_MIN_HEIGHT],
    extrapolate: 'clamp',
  });

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="transparent" translucent barStyle="light-content" />
      
      {/* Header dengan ImageBackground */}
      <Animated.View style={[styles.header, { height: headerHeight }]}>
        <ImageBackground
          source={IlustrationPattern2} // Ganti dengan gambar Anda
          style={styles.imageBackground}
        >
          {/* HEADER */}
          <View style={[BaseStyle.absolute, BaseStyle.index1, BaseStyle.wFull, BaseStyle.nav, nav === true ? BaseStyle.navScroll : undefined]}>
            {status === 1 ? (
                <>
                  {user.map((value, y) => {
                    return (
                      <HeaderLogin key={y} avatar={value.avatar} userName={value.userName} color={nav} />
                    )
                  })}
                </>
              ) : (
                <HeaderNotLogin navigation={navigation} />
              )
            }
          </View>
        </ImageBackground>
      </Animated.View>

      {/* Konten ScrollView */}
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        <Text style={styles.contentText}>
          {/* Tambahkan konten panjang untuk menggulir */}
          {Array(50).fill('Ini adalah konten panjang.\n').join('')}
        </Text>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    overflow: 'hidden',
    zIndex: 1,
  },
  imageBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 200, // Pastikan konten tidak tertimpa header
  },
  contentText: {
    fontSize: 16,
    lineHeight: 24,
    padding: 16,
    color: '#333',
  },
});

export default Tawaf;
