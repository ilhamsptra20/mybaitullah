import { StyleSheet, Text, View, Dimensions, StatusBar, TouchableOpacity, ScrollView, Image, ImageBackground } from 'react-native'
import React, {useState, useEffect} from 'react'
import { useRoute } from '@react-navigation/native';

// COMPONENT
import { Button, DatePickerInput, RadioButton, TextInput } from '../../components/index.js';

// ICON
import {LogoBankBCA, IconCalendarGreen, IconCaretLeftBlack, IconClockGreen, IconLocationGreen, IconQrcodeNonactive, IlustrationPattern5, IconUserLine, IconXMarkWhite, IconBiodataNonactive, IconBayarActive, IconQrcodeActive, IconBayarNonactive, IconCheckGreen, IlustrationSuccess, IlustrationPending} from '../../assets/index.js'

// STYLE
import BaseStyle from '../../assets/style/AppStyle.js'

// API

const OrderStatus = ({navigation}) => {
  // AMBIL ID TICKET
  const route = useRoute();
  const {idTicket} = route.params

  // AMBIL METODE PEMBAYARAN
  const [paymentMethod, setPaymentMethod] = useState()

  const width = Dimensions.get('window').width;
  const height = Dimensions.get('window').height;

  // PACKAGE HEIGHT COMPONENT
  const [ticketComponentHeight, setTicketComponentHeight] = useState(0);

  // NAV SHADOW
  const [navShadow, setNavShadow] = useState(false);

  // status 0 belum login
  // status 1 sudah login
  let [status, setStatus] = useState(1);

  // KONFIRMASI
  const [confirmation, setConfirmation] = useState(1)
    
  return (
    <View style={[BaseStyle.container, BaseStyle.relative]}>
      <StatusBar backgroundColor='transparent' barStyle='dark-content' translucent={true} />

      {/* HEADER */}
      <View style={[BaseStyle.absolute, BaseStyle.index1, BaseStyle.wFull, navShadow === true ? BaseStyle.BgWhite : BaseStyle.BgTrasnparent, navShadow === true ? BaseStyle.navScroll : undefined, ({paddingTop: StatusBar.currentHeight + 10, paddingHorizontal: 14, paddingBottom: 10})]}>
        <View style={[BaseStyle.row, BaseStyle.justifyBetween, BaseStyle.alignItemsCenter, BaseStyle.pb5, BaseStyle.BgTrasnparent]}>
          <View style={[BaseStyle.w30, BaseStyle.w30]} />
          <Text style={[BaseStyle.MaisonBold, navShadow === true ? BaseStyle.textBlack : BaseStyle.textWhite, BaseStyle.textXL]}>Pesanan</Text>
          <View style={[BaseStyle.w30, BaseStyle.w30]} />
        </View>
      </View>

      <ScrollView
          showsVerticalScrollIndicator={false}
          onScroll={e => {
            let offset = e.nativeEvent.contentOffset.y
            if(offset >= 1){
              setNavShadow(true)
            }else{
              setNavShadow(false)
            }
          }}
      >
        <ImageBackground source={IlustrationPattern5} style={[BaseStyle.relative, BaseStyle.wFull, BaseStyle.h180, ({paddingTop: StatusBar.currentHeight})]} imageStyle={{borderBottomLeftRadius: 30, borderBottomRightRadius: 30}}>
          {/* STEP */}
          <View style={[BaseStyle.wrap, ({paddingTop: 60})]}>
            <View style={[BaseStyle.row, BaseStyle.justifyBetween, BaseStyle.alignItemsCenter]}>
              <View style={[BaseStyle.w70, BaseStyle.alignItemsCenter]}>
                <View style={[BaseStyle.justifyCenter, BaseStyle.alignItemsCenter, BaseStyle.borderWhite, BaseStyle.mb5, ({width: 24, height: 24, borderRadius: 24})]}>
                  <IconBiodataNonactive width={16} height={16} />
                </View>
                <Text style={[BaseStyle.MaisonBook, BaseStyle.textWhite, BaseStyle.textXS1, BaseStyle.textCenter]}>STEP 1</Text>
                <Text style={[BaseStyle.MaisonBold, BaseStyle.textWhite, BaseStyle.textSM, BaseStyle.textCenter]}>Biodata</Text>
              </View>
              <View style={[BaseStyle.dashedBorderBox, ({width: '20%', borderColor: '#FFFFFF'})]} />
              <View style={[BaseStyle.w70, BaseStyle.alignItemsCenter]}>
                <View style={[BaseStyle.justifyCenter, BaseStyle.alignItemsCenter, BaseStyle.borderWhite, BaseStyle.mb5, ({width: 24, height: 24, borderRadius: 24})]}>
                  <IconBayarNonactive width={12} height={12} />
                </View>
                <Text style={[BaseStyle.MaisonBook, BaseStyle.textWhite, BaseStyle.textXS1, BaseStyle.textCenter]}>STEP 2</Text>
                <Text style={[BaseStyle.MaisonBold, BaseStyle.textWhite, BaseStyle.textSM, BaseStyle.textCenter]}>Bayar</Text>
              </View>
              <View style={[BaseStyle.dashedBorderBox, ({width: '20%', borderColor: '#FFFFFF'})]} />
              <View style={[BaseStyle.w70, BaseStyle.alignItemsCenter]}>
                <View style={[BaseStyle.justifyCenter, BaseStyle.alignItemsCenter, BaseStyle.BgWhite, BaseStyle.mb5, ({width: 24, height: 24, borderRadius: 24})]}>
                  <IconQrcodeActive width={14} height={14} />
                </View>
                <Text style={[BaseStyle.MaisonBook, BaseStyle.textWhite, BaseStyle.textXS1, BaseStyle.textCenter]}>STEP 3</Text>
                <Text style={[BaseStyle.MaisonBold, BaseStyle.textWhite, BaseStyle.textSM, BaseStyle.textCenter]}>Pesanan</Text>
              </View>
            </View>
          </View>
        </ImageBackground>

        <View
          style={[BaseStyle.relative, BaseStyle.wrap, BaseStyle.alignItemsCenter, BaseStyle.index1, ({marginTop: -30})]}
          onLayout={(event) => {
            const { height } = event.nativeEvent.layout;
            setTicketComponentHeight(height);
          }}
        >
          <View style={[BaseStyle.alignItemsCenter, BaseStyle.BgWhite, BaseStyle.shadow, BaseStyle.p40, BaseStyle.radius10, BaseStyle.wFull]}>
            <View style={[BaseStyle.alignItemsCenter]}>
              <Text style={[BaseStyle.MaisonBold, BaseStyle.textBlack, BaseStyle.textSM, BaseStyle.textCenter, BaseStyle.mb20]}>Konfirmasi</Text>
              {confirmation === 1 ? (
                  <View style={[BaseStyle.alignItemsCenter]}>
                    <IlustrationSuccess width={140} height={140} />
                    <View style={[BaseStyle.h20]} />
                    <Text style={[BaseStyle.MaisonBold, BaseStyle.textLightGreen500, BaseStyle.textSM, BaseStyle.textCenter, BaseStyle.mb20]}>Berhasil</Text>
                  </View>
                ) : (
                  <View style={[BaseStyle.alignItemsCenter]}>
                    <IlustrationPending width={140} height={140} />
                    <View style={[BaseStyle.h20]} />
                    <Text style={[BaseStyle.MaisonBold, BaseStyle.textLightGreen500, BaseStyle.textSM, BaseStyle.textCenter, BaseStyle.mb20]}>Menunggu Konfirmasi</Text>
                  </View>
                )
              }
            </View>
            <View style={[BaseStyle.alignItemsCenter, BaseStyle.mt60, BaseStyle.wFull]}>
              <Text style={[BaseStyle.MaisonBook, BaseStyle.textBlack, BaseStyle.textXS, BaseStyle.textCenter, BaseStyle.mb20]}>Kode Pemesanan Anda: 123456789</Text>
              <Button text="Lihat Tiket" color="#FFFFFF" backgroundColor="#33C060" borderRadius={24} paddingVertical={14} width='100%' onPress={() => navigation.navigate('OrderQrCode', {idTicket: idTicket})} />
              <View style={[BaseStyle.h10]} />
              <Button text="Kembali ke Beranda" color="#33C060" backgroundColor='#FFFFFF' borderColor='#33C060' borderRadius={24} paddingVertical={14} width='100%' onPress={() => navigation.navigate('MainApp', {screen: 'Home'})} />
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}

export default OrderStatus

const styles = StyleSheet.create({})