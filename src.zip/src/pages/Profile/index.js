import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { HeaderImageScrollView } from '../../components'

const Profile = () => {
  return (
    <View>
      <HeaderImageScrollView />
    </View>
  )
}

export default Profile

const styles = StyleSheet.create({
})