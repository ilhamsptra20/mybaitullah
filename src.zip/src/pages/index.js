import Home from './Home';
import Tawaf from './Tawaf';
import Ticket from './Ticket';
import CeritaBaitullah from './CeritaBaitullah';
import CeritaBaitullahList from './CeritaBaitullahList';
import CeritaBaitullahDetail from './CeritaBaitullahDetail';
import Profile from './Profile';
import TicketList from './TicketList';
import TicketDetail from './TicketDetail';
import OrderBiodata from './OrderBiodata';
import OrderPay from './OrderPay';
import OrderPaymentMethod from './OrderPaymentMethod';
import OrderStatus from './OrderStatus';
import OrderQrCode from './OrderQrCode';

export {
    Home,
    Tawaf,
    Ticket,
    CeritaBaitullah,
    CeritaBaitullahList,
    CeritaBaitullahDetail,
    Profile,
    TicketList,
    TicketDetail,
    OrderBiodata,
    OrderPay,
    OrderPaymentMethod,
    OrderStatus,
    OrderQrCode,
}