import { useState, useEffect } from 'react';
import fetchUser from '../../api/apiUser/apiUser.js';

const userFetch = () => {
    const [user, setUser] = useState([]);
    const [loadingUser, setLoadingUser] = useState(true);
    const [errorUser, setErrorUser] = useState(null);

    useEffect(() => {
        const loadUserData = async () => {
            try {
                const response = fetchUser;
                setUser(response);
            } catch (err) {
                setErrorUser(err.message);
            } finally {
                setLoadingUser(false);
            }
        };
        loadUserData();
    }, []);

    return { user, loadingUser, errorUser };
};

export default userFetch;